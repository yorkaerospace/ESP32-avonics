Common Issues
=============

.. doxygenpage:: md_COMMON_ISSUES
   :content-only:


.. image:: ../../images/ghetto_sheilding_1.png
    :target: https://github.com/nRF24/RF24/blob/master/images/ghetto_sheilding_1.png
    :height: 750

.. image:: ../../images/ghetto_sheilding_2.png
    :target: https://github.com/nRF24/RF24/blob/master/images/ghetto_sheilding_2.png
    :height: 750
